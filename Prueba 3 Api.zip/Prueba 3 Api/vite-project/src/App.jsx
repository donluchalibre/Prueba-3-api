import "./App.css";
import MiApi from "./components/MiApi";

function App() {
  return (
    <>
      <h1>Consultar Pokémon</h1>
      <h2>Lista de Pokémon</h2>
      <MiApi />
      <footer>
        Todos los derechos reservados <br /> @Donluchalibre
      </footer>
    </>
  );
}

export default App;
