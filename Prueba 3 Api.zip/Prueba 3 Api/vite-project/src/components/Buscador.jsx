const Buscador = ({ onTypeChange, onOrdenChange, allPokemonData }) => {
  const handleTypeChange = (event) => {
    const selectedType = event.target.value;
    onTypeChange(selectedType);
  };

  const handleOrdenChange = (event) => {
    const selectedOrden = event.target.value;
    onOrdenChange(selectedOrden);
  };

  const uniqueTypes = [
    ...new Set(allPokemonData.flatMap((pokemon) => pokemon.types))
  ].sort();

  return (
    <form className="Opciones" onSubmit={(e) => e.preventDefault()}>
      <div className="mb-3">
        <label htmlFor="tipo" className="form-label"><strong>Filtrar por Tipo:</strong></label>
        <select className="form-select" id="tipo" onChange={handleTypeChange}>
          <option value="">Todos los Tipos</option>
          {uniqueTypes.map((type, index) => (
            <option key={index} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>
      <div className="mb-3">
        <label htmlFor="orden" className="form-label"><strong>Ordenar por:</strong></label>
        <select className="form-select" id="orden" onChange={handleOrdenChange}>
          <option value="">Ordenar por</option>
          <option value="id">ID</option>
          <option value="nombre">Nombre</option>
        </select>
      </div>
    </form>
  );
};

export default Buscador;
