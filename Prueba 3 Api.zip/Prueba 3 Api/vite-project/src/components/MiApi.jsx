import { useState, useEffect } from "react";
import axios from "axios";
import { Card, Container } from "react-bootstrap";
import Buscador from "./Buscador";

const MiApi = () => {
  const [pokemonData, setPokemonData] = useState([]);
  const [allPokemonData, setAllPokemonData] = useState([]);
  const [orden, setOrden] = useState("");
  const [selectedType, setSelectedType] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("https://pokeapi.co/api/v2/pokemon?limit=151");
        const detailedPokemonPromises = response.data.results.map(async (pokemon) => {
          const detailResponse = await axios.get(pokemon.url);
          return {
            id: detailResponse.data.id,
            name: detailResponse.data.name,
            image: detailResponse.data.sprites.front_default,
            types: detailResponse.data.types.map((type) => type.type.name),
            height: detailResponse.data.height,
            weight: detailResponse.data.weight,
          };
        });

        const detailedPokemon = await Promise.all(detailedPokemonPromises);
        setPokemonData(detailedPokemon);
        setAllPokemonData(detailedPokemon);
      } catch (error) {
        console.log("Error al obtener datos de la API:", error);
      }
    };
    fetchData();
  }, []);

  const handleTypeChange = (type) => {
    setSelectedType(type);
    if (type === "") {
      setPokemonData(allPokemonData);
    } else {
      const filteredData = allPokemonData.filter((item) => item.types.includes(type));
      setPokemonData(filteredData);
    }
  };

  const handleOrdenChange = (selectedOrden) => {
    setOrden(selectedOrden);
    let sortedData = [...pokemonData];

    if (selectedOrden === "id") {
      sortedData = sortedData.sort((a, b) => a.id - b.id);
    } else if (selectedOrden === "nombre") {
      sortedData = sortedData.sort((a, b) => a.name.localeCompare(b.name));
    }

    setPokemonData(sortedData);
  };

  return (
    <Container>
      <Buscador
        onTypeChange={handleTypeChange}
        onOrdenChange={handleOrdenChange}
        allPokemonData={allPokemonData}
      />
      <div className="mt-5 d-flex justify-content-center gap-3 CardContainer">
        {pokemonData.length > 0 ? (
          pokemonData.map((pokemon, index) => (
            <Card key={index} className="Card">
              <Card.Body>
                <Card.Title>{pokemon.name}</Card.Title>
                <img
                  src={pokemon.image}
                  alt={pokemon.name}
                  style={{ width: "150px", height: "150px" }}
                />
                <hr />
                <Card.Text>ID: {pokemon.id}</Card.Text>
                <Card.Text>Tipos: {pokemon.types.join(", ")}</Card.Text>
                <Card.Text>Altura: {pokemon.height / 10} m</Card.Text>
                <Card.Text>Peso: {pokemon.weight / 10} kg</Card.Text>
              </Card.Body>
            </Card>
          ))
        ) : (
          <h1>No hay Pokémon para mostrar</h1>
        )}
      </div>
    </Container>
  );
};

export default MiApi;
